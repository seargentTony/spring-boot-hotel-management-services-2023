package com.ybl.rating.RatingService.exceptions;

public class ResourceNotFoundException extends Exception{
    public ResourceNotFoundException(String message) {

        super(message);
    }

    public ResourceNotFoundException(){

        super("Resource not found !!");
    }
}
