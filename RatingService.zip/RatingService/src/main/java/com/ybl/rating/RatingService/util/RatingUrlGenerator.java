package com.ybl.rating.RatingService.util;

import com.ybl.rating.RatingService.entities.Rating;

import java.net.URLEncoder;

public class RatingUrlGenerator {
    public String generateHotelUrl(String hotelName) {
        try {
            String encodedHotelName = URLEncoder.encode(hotelName, "UTF-8");
            return "http://localhost:8083/ratings/hotels/" + encodedHotelName;
        } catch (Exception e) {
            // Handle the exception (e.g., log it or throw a custom exception)
            return ""; // Return an empty URL or handle the error accordingly
        }
    }

//    public void printHotelUrl(Rating rating) {
//        String hotelName = rating.getHotelName();
//        String url = generateHotelUrl(hotelName);
//        System.out.println("Hotel URL: " + url);
//    }
//
//    // Assuming you have a Rating object named "rating"
//    RatingUrlGenerator urlGenerator = new RatingUrlGenerator();
//    urlGenerator.printHotelUrl(rating);
}
