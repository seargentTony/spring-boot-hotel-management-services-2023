package com.ybl.rating.RatingService.services;

import com.ybl.rating.RatingService.entities.Rating;
import com.ybl.rating.RatingService.exceptions.ResourceNotFoundException;

import java.util.List;
import java.util.SimpleTimeZone;

public interface RatingService {
    //create
    Rating create(Rating rating);

    //getAll
    List<Rating> getRatings();

    //get all by userId
    List<Rating> getRatingByUserId(String userId);

    //get all by hotelId
    List<Rating> getRatingByHotelId(String hotelId);

    //get all by hotelName
    List<Rating> getRatingByHotelName(String hotelName);

    //update by rating by userId
    Rating updateRatingByUID(String ratingId, String userId) throws ResourceNotFoundException;
}
