package com.ybl.rating.RatingService.services.impl;

import com.ybl.rating.RatingService.entities.Rating;
import com.ybl.rating.RatingService.exceptions.ResourceNotFoundException;
import com.ybl.rating.RatingService.repository.RatingRepository;
import com.ybl.rating.RatingService.services.RatingService;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class RatingServiceImpl implements RatingService {

    @Autowired
    private RatingRepository ratingRepository;

    //create rating
    @Override
    public Rating create(Rating rating) {
        String ratingId = UUID.randomUUID().toString();
        rating.setRatingId(ratingId);
        return ratingRepository.save(rating);
    }

    //get All
    @Override
    public List<Rating> getRatings() {
        return ratingRepository.findAll();
    }

    @Override
    public List<Rating> getRatingByUserId(String userId) {
//        return (List<Rating>) ratingRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("hotel with given id not found !!"));
        return ratingRepository.findRatingByUserId(userId);
    }

    @Override
    public List<Rating> getRatingByHotelId(String hotelId) {
        return ratingRepository.findRatingByHotelId(hotelId);
//        return (List<Rating>) ratingRepository.findById(hotelId).orElseThrow(() -> new ResourceNotFoundException("hotel with given id not found !!"));
    }

    @Override
    public List<Rating> getRatingByHotelName(String hotelName) {
        return ratingRepository.findRatingByHotelName(hotelName);
    }

    @Override
    public Rating updateRatingByUID(String ratingId, String userId) throws ResourceNotFoundException{
        Rating existingRating = ratingRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("Rating with Id "+ratingId+"Not Found!!"));
        try {
            existingRating.setRating(existingRating.getRating());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return ratingRepository.save(existingRating);
    }

}
